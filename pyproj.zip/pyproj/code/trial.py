import numpy as np
import cv2
import face_recognition
import cvzone
import pickle
from firebase_admin import credentials, initialize_app, db as firebase_db, storage
from datetime import datetime
import os

# Function to load images from folder
def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder, filename))
        if img is not None:
            images.append(cv2.resize(img, (414, 633)))
    return images

# Load Firebase credentials
script_dir = os.path.dirname(os.path.abspath(__file__))
json_path = os.path.join(script_dir, 'serviceAccountKey.json')
cred = credentials.Certificate(json_path)
firebase_app = initialize_app(cred, {
    'databaseURL': 'https://face-cbaa5-default-rtdb.firebaseio.com/',
    'storageBucket': 'face-cbaa5.appspot.com'
})
bucket = storage.bucket()

# Capture video from webcam
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# Load background image and mode images
imgBackground = cv2.imread('Resources/background.png')
modePathList = os.listdir('Resources/Modes')
imgModeList = load_images_from_folder('Resources/Modes')

# Load face encodings
print("Loading Encode File ...")
with open('EncodeFile.p', 'rb') as file:
    encodeListKnownWithIds = pickle.load(file)
encodeListKnown, studentIds = encodeListKnownWithIds
print("Encode File Loaded")

# Initialize variables
modeType = 0
counter = 0
id = -1
imgStudent = []
last_attendance_time = datetime.now()

while True:
    success, img = cap.read()
    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    # Display webcam feed and background image
    imgBackground[162:162 + 480, 55:55 + 640] = img
    imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

    # Face recognition
    faceCurFrame = face_recognition.face_locations(imgS)
    encodeCurFrame = face_recognition.face_encodings(imgS, faceCurFrame)
    
    if faceCurFrame:
        for encodeFace, faceLoc in zip(encodeCurFrame, faceCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
            matchIndex = np.argmin(faceDis)
            if matches[matchIndex]:
                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                bbox = 55 + x1, 162 + y1, x2 - x1, y2 - y1
                imgBackground = cvzone.cornerRect(imgBackground, bbox, rt=0)
                id = studentIds[matchIndex]
                if counter == 0:
                    cvzone.putTextRect(imgBackground, "Loading", (275, 400))
                    cv2.imshow("Face Attendance", imgBackground)
                    cv2.waitKey(1)
                    counter = 1
                    modeType = 1

    if counter != 0:
        if counter == 1:
            studentInfo = firebase_db.reference(f'Students/{id}').get()
            blob = bucket.blob(f'Images/{id}.jpg')
            try:
                image_bytes = blob.download_as_bytes()
                nparr = np.frombuffer(image_bytes, np.uint8)
                imgStudent = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                imgStudent = cv2.resize(imgStudent, (216, 216))
            except Exception as e:
                print("Error loading image from Firebase storage:", e)
                imgStudent = img
            
            # Update total_attendance field in real-time database
            datetimeObject = datetime.strptime(studentInfo['last_attendance_time'], "%Y-%m-%d %H:%M:%S")
            secondsElapsed = (datetime.now() - datetimeObject).total_seconds()
            print(secondsElapsed)
            if secondsElapsed > 30:
                ref = firebase_db.reference(f'Students/{id}/total_attendance')
                total_attendance_value = studentInfo.get('total_attendance')
                if not isinstance(total_attendance_value, int):
                    total_attendance_value = 0
                studentInfo['total_attendance'] = str(total_attendance_value + 1)
                ref.set(studentInfo['total_attendance'])  # Convert to string before setting
                ref.child('last_attendance_time').set(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                last_attendance_time = datetime.now()  # Update last attendance time
            else:
                modeType = 3
                counter = 0

    # Display attendance information and student image
    if counter <= 10:
        cv2.putText(imgBackground, str(studentInfo.get('total_attendance', 0)), (861, 120), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(imgBackground, str(studentInfo.get('major', '')), (1005, 530), cv2.FONT_HERSHEY_COMPLEX, 0.55, (255, 255, 255), 2)
        cv2.putText(imgBackground, str(id), (1005, 475), cv2.FONT_HERSHEY_COMPLEX, 0.55, (255, 255, 255), 2)
        cv2.putText(imgBackground, str(studentInfo.get('standing', '')), (900, 635), cv2.FONT_HERSHEY_COMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(imgBackground, str(studentInfo.get('year', '')), (1023, 635), cv2.FONT_HERSHEY_COMPLEX, 0.6, (255, 255, 255), 2)
        cv2.putText(imgBackground, str(studentInfo.get('starting_year', '')), (1123, 635), cv2.FONT_HERSHEY_COMPLEX, 0.6, (255, 255, 255), 2)
        (w, h), _ = cv2.getTextSize(str(studentInfo.get('name', '')), cv2.FONT_HERSHEY_COMPLEX, 0.8, 1)
        offset = (414 - w) // 2
        cv2.putText(imgBackground, str(studentInfo.get('name', '')), (812 + offset, 420), cv2.FONT_HERSHEY_COMPLEX, 0.6, (255, 255, 255), 2)
        imgBackground[175:175 + 216, 909:909 + 216] = imgStudent
        counter += 1

    # Reset counters and modeType when necessary
    if counter >= 20:
        counter = 0
        modeType = 0
        studentInfo = {}
        imgStudent = []
    elif modeType != 3 and 10 < counter < 20:
        modeType = 2

    # Display webcam and attendance window
    cv2.imshow("Webcam", img)
    cv2.imshow("Face Attendance", imgBackground)
    cv2.waitKey(1)
