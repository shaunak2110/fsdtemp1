from firebase_admin import credentials, initialize_app, db as firebase_db
import os

script_dir = os.path.dirname(os.path.abspath(__file__))
json_path = os.path.join(script_dir, 'serviceAccountKey.json')

cred = credentials.Certificate(json_path)

firebase_app = initialize_app(cred, {
    'databaseURL': 'https://face-cbaa5-default-rtdb.firebaseio.com/'
})

db = firebase_db.reference('Students')
#student is the attribute , which is there on real time data base

data = {
#this is the data which is being uploaded to realtime database.
    '321654': {
        'name': 'Rishabh Oswal',
        'major': 'Python',
        'starting_year': 2020,
        'total_attendance': 9,
        'standing': 'Good',
        'year': 2,
        'last_attendance_time': '2024-02-12 00:54:34',
    },
    '852741': {
        'name': 'Shaunak Dalvi',
        'major': 'Robotics',
        'starting_year': 2020,
        'total_attendance': 7,
        'standing': 'Good',
        'year': 2,
        'last_attendance_time': '2024-01-12 00:54:34',
    },
    '985462': {
        'name': 'Sudhanshu Athanimath',
        'major': 'OS',
        'starting_year': 2020,
        'total_attendance': 5,
        'standing': 'Good',
        'year': 2,
        'last_attendance_time': '2024-01-12 00:54:34',
    }
}

for key, value in data.items():
    db.child(key).set(value)
